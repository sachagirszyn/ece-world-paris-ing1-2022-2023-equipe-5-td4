#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <allegro.h>

typedef struct BITMAP{
	int w, h; 		// longueur et hauteur de l'image
	int clip; 		// clip actif 1 ou non 0
	int cl, ct, cr, cb; 	// zone clip comprise entre (cl,ct) et (cr,cb)
	void*dat; 		// ces deux champs pour les datas de l'image (matrice)
	unsigned char *line[ ];//matrice d�entiers
}t_BITMAP ;





int main()
{
    allegro_init();
    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,800,600,0,0))!=0)
   { 	allegro_message("Pb de mode graphique") ;
        allegro_exit();
        exit(EXIT_FAILURE); }
    int install_mouse();


    allegro_message("Bonjour, bienvenu aux jackpot, cliquer sur la machine pour essayer d'obtenir une de nos trois combinaisson gagante, ou perdante");


    t_BITMAP* page;
    page=create_bitmap(SCREEN_W,SCREEN_H);
    clear_bitmap(page);

    t_BITMAP* background;
    t_BITMAP* sabre;
    t_BITMAP* bow;
    t_BITMAP* bullet;
    t_BITMAP* rot1[3];
    t_BITMAP* rot2[3];
    t_BITMAP* rot3[3];

    background=load_bitmap("jacpot-jacpot.bmp", NULL);
    sabre=load_bitmap("sabre-jacpot.bmp",NULL);
    bow=load_bitmap("arc-jacpot.bmp", NULL);
    bullet=load_bitmap("balle-jacpot.bmp", NULL);

    rot1[1]=rot2[1]=rot3[1]=sabre;
    rot1[2]=rot2[2]=rot3[2]=bow;
    rot1[3]=rot2[3]=rot3[3]=bullet;


     if (mouse_b & 2){
        int j=rand()%(20-0+1)-0;
        for (int i=0; i<j;i++){
            int y=rand()%(3-1+1)-1;
            rot1[y];
            rot2[y];
            rot3[y];
        }
        if(rot1[y]=rot2[y]=rot3[y]=sabre){
          allegro_message("F�licitation vous avez gagnez deux tickets!");
        }
        else if(rot1[y]=rot2[y]=rot3[y]=bow){
          allegro_message("Bravo vous avez gagnez un ticket.");

        }
        else if(rot1[y]=rot2[y]=rot3[y]=bullet){
            allegro_message("Pas de chance vous avez perdu un ticket!");
        }
        else{
            allegro_message("Dommage vous n'avez gagner aucun ticket");
        }
     }


return 0;
} END_OF_MAIN() ;
